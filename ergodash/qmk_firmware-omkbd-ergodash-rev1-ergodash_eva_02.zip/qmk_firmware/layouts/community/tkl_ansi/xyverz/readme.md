2019-10-16 Updated to bring keymap up to current.
