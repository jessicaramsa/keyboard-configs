#pragma once

#define NO_ACTION_ONESHOT
#undef LOCKING_SUPPORT_ENABLE

#define LAYER_STATE_8BIT
#define MAX_LAYER 4
